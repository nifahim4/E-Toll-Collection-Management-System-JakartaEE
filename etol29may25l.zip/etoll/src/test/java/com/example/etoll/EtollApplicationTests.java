package com.example.etoll;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EtollApplicationTests {

	@Test
	void contextLoads() {
	}

}
