package com.example.etoll;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtollApplication {
	public static void main(String[] args) {
		SpringApplication.run(EtollApplication.class, args);
	}
}